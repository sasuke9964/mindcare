<?php
// Include database connection
include '../includes/db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <style>
    /* General Body Styles */
    body {
      font-family: Arial, sans-serif;
      background-color: #1e1e1e; /* Changed from #fffaf5 */
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh; /* Full-screen height */
      color: #c8c8c8; /* Added text color */
    }

    /* Login Container */
    .login-container {
      background-color: #282828; /* Changed from #ffe6f0 */
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); /* Adjusted shadow */
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    /* Heading Style */
    .login-container h2 {
      color: #007bff; /* Changed from #5a5a5a */
      margin-bottom: 20px;
    }

    /* Form Label Style */
    label {
      display: block;
      text-align: left;
      margin-bottom: 5px;
      font-size: 14px;
      color: #c8c8c8; /* Changed from #5a5a5a */
    }

    /* Input Fields Style */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #555; /* Changed from #d3a4c1 */
      border-radius: 5px;
      box-sizing: border-box;
      font-size: 14px;
      background-color: #343a40; /* Dark input background */
      color: #c8c8c8; /* Light input text */
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      outline: none;
      border-color: #007bff; /* Changed from #ff99c8 */
      box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Adjusted shadow color */
    }

    /* Login Button Style */
    button[type="submit"] {
      background-color: #007bff; /* Changed from #ff99c8 */
      color: white;
      border: none;
      border-radius: 5px;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button[type="submit"]:hover {
      background-color: #0056b3; /* Changed from #cc6699 */
    }

    /* Responsive Design */
    @media (max-width: 480px) {
      .login-container {
        padding: 20px;
      }

      input[type="text"],
      input[type="password"] {
        font-size: 13px;
      }

      button[type="submit"] {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Admin Login</h2>
    <form action="../process/admin_login.php" method="POST">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
