from flask import Flask
from flask_cors import CORS
import os
import gradio as gr

from langchain_groq import ChatGroq
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter

app = Flask(__name__)
CORS(app)
print("Initializing Chatbot...")

# Initialize LLM using ChatGroq
def initialize_llm():
    llm = ChatGroq(
        temperature=0,
        groq_api_key="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",
        model_name="llama-3.3-70b-versatile"
    )
    return llm

# Create or load the vector database (assumes PDFs and DB folder are inside the 'chatbot' folder)
def create_vector_db():
    # PDFs are stored in the "chatbot" folder
    loader = DirectoryLoader("chatbot", glob="*.pdf", loader_cls=PyPDFLoader)
    documents = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    texts = text_splitter.split_documents(documents)
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    # Save Chroma DB inside "chatbot/chroma_db"
    vector_db = Chroma.from_documents(texts, embeddings, persist_directory="chatbot/chroma_db")
    vector_db.persist()
    print("ChromaDB created and data saved")
    return vector_db

# Set up the QA chain using the vector DB and LLM
def setup_qa_chain(vector_db, llm):
    retriever = vector_db.as_retriever()
    
    # Corrected Prompt Template
    prompt_template = """
    You are MindCare, a compassionate and understanding mental health chatbot here to support users in their well-being journey. Your responses are warm, friendly, and to the point, offering clear and thoughtful guidance based on general mental health knowledge. You listen attentively, respond with empathy, and create a safe space where users feel heard and valued. If a question is unrelated to mental health, acknowledge it briefly and gently steer the conversation back to well-being. Your goal is to provide support, reassurance, and practical advice in a way that feels natural and human. Keep responses concise yet meaningful—comforting but never overly wordy.

    Context: {context}
    User: {question}
    Chatbot:
    """
    PROMPT = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        chain_type_kwargs={"prompt": PROMPT}
    )
    return qa_chain

llm = initialize_llm()
db_path = "chatbot/chroma_db"
if not os.path.exists(db_path):
    vector_db = create_vector_db()
else:
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    vector_db = Chroma(persist_directory=db_path, embedding_function=embeddings)
qa_chain = setup_qa_chain(vector_db, llm)

def chatbot_response(user_input, history=[]):
    if not user_input.strip():
        return "Please provide a valid input."
    response_dict = qa_chain.invoke({"context": "", "query": user_input})
    response = response_dict.get("result", "I couldn't generate a response.")
    return response


# Custom CSS for Pink Theme
custom_css = """
    body {
        background-color: #181818 !important;
        color: #fff !important;
    }
    .gradio-container, .block, .main, .container, .chatbot, .chatbot-message, .chatbot-message.user, .chatbot-message.bot {
        background-color: #222 !important;
        color: #fff !important;
        border-radius: 10px !important;
    }
    .gradio-container h1, .gradio-container h2, .gradio-container h3, .gradio-container h4, .gradio-container h5, .gradio-container h6 {
        color: #007bff !important;
        background: transparent !important;
    }
    .message-container, .chatbot-message.bot {
        background-color: #282828 !important;
        color: #fff !important;
        border-radius: 10px !important;
        padding: 10px !important;
    }
    .message-container.user, .chatbot-message.user {
        background-color: #007bff !important;
        color: #fff !important;
    }
    button, .back-btn, .gr-button, .gradio-button {
        background-color: #007bff !important;
        color: #fff !important;
        border-radius: 8px !important;
        font-weight: bold !important;
        border: none !important;
        transition: background 0.3s;
    }
    button:hover, .back-btn:hover, .gr-button:hover, .gradio-button:hover {
        background-color: #0056b3 !important;
    }
    input, textarea {
        background-color: #333 !important;
        color: #fff !important;
        border-radius: 5px !important;
        border: 1px solid #222 !important;
    }
    .markdown-body {
        color: #c8c8c8 !important;
    }
    .gradio-container {
        box-shadow: 0 0 10px rgba(0,0,0,0.7) !important;
    }
    /* Remove pink header background */
    .svelte-1ipelgc, .svelte-1ipelgc.svelte-1ipelgc, .svelte-1ipelgc>div:first-child {
        background: transparent !important;
    }
"""
# JavaScript for Back button
redirect_js = """
<button onclick=\"window.location.href='http://localhost:8000/index.php'\" style=\"padding:10px 15px; background-color:#007bff; color:white; border:none; cursor:pointer; font-size:16px; margin-top:10px; border-radius:8px; font-weight:bold;\">
    \ud83d\udd19 Back to Home
</button>
"""
# Create Gradio interface inside Blocks
with gr.Blocks(css=custom_css) as chatbot_app:
    gr.Markdown("<h1 style='text-align: center;'> 🧠 MindCare Mental Health Chatbot 🤖</h1>")
    gr.Markdown("<p style='text-align: center;'>A compassionate chatbot designed to assist with mental well-being. Note: For serious concerns, contact a professional.</p>")
    
    chatbot = gr.ChatInterface(fn=chatbot_response, title="MindCare Chatbot")
    gr.HTML(redirect_js)
chatbot_app.launch(server_name="0.0.0.0", server_port=5010, share=False)
