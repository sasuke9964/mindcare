<?php
$password = 'your_NEW_easy_to_remember_password'; // REPLACE THIS with your desired NEW password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);
echo $hashed_password;
?> 