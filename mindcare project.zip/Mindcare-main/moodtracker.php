<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
<script src="https://d3js.org/d3.v6.min.js"></script>
</head>
<body>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Set a consistent background across the whole webpage */
body {
    background: #1e1e1e; /* Dark theme background */
    font-family: 'Arial', sans-serif;
    display: flex;
    flex-direction: column;
    color: #c8c8c8; /* Light text color */
}
.profile-icon {
    margin-left: 10px;
    text-decoration: none;
}

.profile-img {
    height: 30px; /* Adjust size as needed */
    width: auto;  /* Keeps the aspect ratio */
    vertical-align: middle;
    border-radius: 100px;
}
/* Logo Styling */
.logo {
  display: contents;
  align-items: center;
  justify-content: center;
}

.logo-img {
  width: 120px;    /* Adjust the size of the logo */
  height: 120px;    /* Maintain the aspect ratio of the logo */
  object-fit: contain;  /* Ensures the logo fits inside the container */
}
.logo-img {
  width: 150%;  /* Responsive size */
  max-width: 200px;  /* Maximum size */
  height: auto;
}
header nav ul {
  list-style-type: none;
  padding: 0;
}

header nav ul li {
  display: inline;
  margin: 0 15px;
}

header nav ul li a {
  text-decoration: none;
  color: #c8c8c8; /* Light gray text color */
  font-weight: bold;
  padding: 10px;
  border-radius: 5px;
  transition: background-color 0.3s ease;
}


header nav ul li a:hover {
  background-color: #0056b3; /* Darker blue */
}
header nav{
  background: #282828; /* Dark gray background */
  color: #c8c8c8; /* Light gray text color */
  display: flex;
  padding: 10px;
  text-align: center;
  justify-content: space-between;
  align-items: center;

  top: 0;
  z-index: 10;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

nav ul {
  list-style: none;
  display: flex;
}

nav ul li {
  margin: 0 1rem;
}

nav ul li a {
  color: #c8c8c8; /* Light gray for links */
  text-decoration: none;
  font-weight: bold;
  transition: color 0.3s ease;
}

nav ul li a:hover {
  color: #007bff; /* Blue hover effect */
}

/* Buttons in Navbar */
.nav-buttons {
  display: flex;
  gap: 10px;
}

.nav-btn {
  padding: 10px 15px;
  background-color: #007bff; /* Blue for buttons */
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease;
}

.nav-btn:hover {
  background-color: #0056b3; /* Slightly darker blue hover */
}
.profile-icon {
  margin-left: 10px;
  text-decoration: none;
}
.profile-img {
  height: 24px; /* Adjust size as needed */
  width: auto;
  vertical-align: middle;
}


/* Mood Button Styles */
.mood-btn {
    width: 140px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 15px;
    border-radius: 12px;
    cursor: pointer;
    font-size: 18px;
    font-weight: bold;
    color: #c8c8c8; /* Light text color */
    transition: transform 0.3s ease-in-out;
    user-select: none;
    text-align: center;
    border: 2px solid #007bff; /* Blue border */
}

    .mood-btn:hover {
        transform: scale(1.1);
    }
    input[type="radio"]:checked + label {
    background: #007bff; /* Blue background */
    color: white;
    transform: scale(1.1);
    border: 2px solid #0056b3; /* Darker blue border */
    }

    /* Navigation Header */
    .calendar-header {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 15px;
      margin-bottom: 20px;
    }
    .month-name {
      font-size: 20px;
      font-weight: bold;
      color: #c8c8c8; /* Light text color */
    }
    .year-selector {
      font-size: 16px;
      padding: 6px;
      border: 2px solid #007bff; /* Blue border */
      border-radius: 8px;
      color: #c8c8c8; /* Light text color */
      font-weight: bold;
      background: #282828; /* Dark gray background */
      cursor: pointer;
      transition: 0.3s ease;
    }
    .year-selector:hover {
      background: #343a40; /* Darker gray background */
    }
    .nav-button {
      background: #007bff; /* Blue button */
      color: white;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      font-size: 16px;
      border-radius: 8px;
      transition: 0.3s ease;
      box-shadow: 0 3px 8px rgba(0,0,0,0.3); /* Adjusted shadow */
    }
    .nav-button:hover {
      background: #0056b3; /* Darker blue */
    }
/* Calendar Grid */
.calendar-container {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
  width: 90%; 
  max-width: 900px;
  margin: 20px auto;
  background: #282828; /* Dark gray background */
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Adjusted shadow */
}

/* Day Cells (Fixed Size & Structured) */
.day-cell {
  width: 90px;
  height: 90px;
  background: #343a40; /* Darker background */
  border-radius: 8px;
  position: relative;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transition: transform 0.2s ease-in-out, background 0.3s ease;
}

/* Single Mood: Full Background */
.day-cell.single-mood {
  display: flex;
  align-items: center;
  justify-content: center;
  /* Background color based on mood - will be set by JavaScript */
}

/* Hover effect for day cells */
.day-cell:hover {
  transform: scale(1.05);
  background: #3a3a3a; /* Slightly lighter dark background on hover */
}

/* Mood Icons on Cells (for multiple moods) */
.mood-icons {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 5px;
}

.mood-icon {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.2); /* Subtle background */
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}

/* Specific mood icon colors */
.mood-icon.😊 { background-color: #28a745; } /* Green for happy */
.mood-icon.😐 { background-color: #ffc107; } /* Yellow for neutral */
.mood-icon.😢 { background-color: #dc3545; } /* Red for sad */
.mood-icon.😠 { background-color: #fd7e14; } /* Orange for angry */
.mood-icon.😟 { background-color: #6610f2; } /* Indigo for anxious */


/* Date Number */
.date-number {
  position: absolute;
  top: 5px;
  left: 5px;
  font-size: 12px;
  font-weight: bold;
  color: #c8c8c8; /* Light text color */
}

/* Mood Input Section */
.mood-input-section {
  margin-top: 30px;
  text-align: center;
  padding: 20px;
  background: #282828; /* Dark gray background */
  border-radius: 12px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Adjusted shadow */
  width: 90%;
  max-width: 700px;
  margin-left: auto;
  margin-right: auto;
}

.mood-input-section h2 {
  color: #007bff; /* Blue accent color */
  margin-bottom: 20px;
}

.mood-options {
  display: flex;
  justify-content: center;
  gap: 15px;
  flex-wrap: wrap;
}

.mood-option input[type="radio"] {
  display: none;
}

.mood-option label {
  display: block;
  padding: 15px 25px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  transition: background-color 0.3s ease;
  border: 2px solid #007bff; /* Blue border */
  color: #c8c8c8; /* Light text color */
  background: #343a40; /* Darker background */
}

.mood-option input[type="radio"]:checked + label {
  background: #007bff; /* Blue background */
  color: white;
  border-color: #0056b3; /* Darker blue border */
}

/* Submit Button */
.submit-btn {
  background: #28a745; /* Green button */
  color: white;
  border: none;
  padding: 12px 25px;
  font-size: 16px;
  border-radius: 8px;
  cursor: pointer;
  margin-top: 20px;
  transition: background-color 0.3s ease;
}

.submit-btn:hover {
  background: #218838; /* Darker green */
}

/* Graph Section */
.graph-section {
  margin-top: 30px;
  text-align: center;
  padding: 20px;
  background: #282828; /* Dark gray background */
  border-radius: 12px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Adjusted shadow */
  width: 90%;
  max-width: 900px;
  margin-left: auto;
  margin-right: auto;
}

.graph-section h2 {
  color: #007bff; /* Blue accent color */
  margin-bottom: 20px;
}

#moodGraph {
  background: #1e1e1e; /* Dark theme background for graph */
  border-radius: 8px;
  padding: 10px;
}

/* Tooltip for Mood Icons */
.mood-tooltip {
  position: absolute;
  background: #343a40; /* Darker background for tooltip */
  color: #c8c8c8; /* Light text color */
  padding: 5px 10px;
  border-radius: 5px;
  font-size: 12px;
  pointer-events: none; /* Allows clicks to pass through */
  z-index: 100; /* Above other content */
  white-space: nowrap;
  opacity: 0;
  transition: opacity 0.2s ease-in-out;
}

</style>
    
<header style="position: sticky; top: 0; z-index: 1000;">
    <nav style="background-color:#282828;">
    <!-- Logo Section -->
    <div class="logo">
      <a href="index.php">
        <img src="assets/images/logo.png" alt="MindCare Logo" class="logo-img">
      </a>
    </div>
    
  
      <ul>
        <li><a href="about.php">About</a></li>
        <li><a href="services.html">Services</a></li>
        <li><a href="therapist.php">Therapists</a></li>
        <li><a href="contact.php">Contact</a></li>
        <?php if (!isset($_SESSION['user_id'])): ?>
        <li><a href="signinsignup\signin.html">Sign In</a></li>
        <li><a href="signinsignup\signup1.php" style="color: #e63946;">Sign Up</a></li>
        <?php endif; ?>
        <a href="profile.php" class="profile-icon" title="Profile">
          <img src="assets/images/profile.gif" alt="Profile Image" class="profile-img">
        </a>
      </ul>
    </nav>
  
  </header>

    <section class="hero-mood" style="display: flex; align-items: center; justify-content: center; gap: 50px; padding: 80px 10%; background: #1e1e1e;">
        <div class="hero-content" style="flex: 1; max-width: 500px; opacity: 1; transform: translateY(0); transition: opacity 0.8s ease-out, transform 0.8s ease-out; color: #c8c8c8;">
            <h1 class="fade-in" style="font-size: 40px; font-weight: bold; color: #007bff;">Track Your Mood, <span style="color: #c8c8c8;">Understand Yourself</span></h1>
            <p class="fade-in" style="font-size: 18px; color: #c8c8c8; margin-top: 15px;">
                Log your emotions daily and visualize them in an interactive <b>calendar and graphs</b>. Gain insights into your emotional well-being through simple yet powerful tracking tools.
            </p>
            <a href="#mood-tracker" class="hero-btn fade-in" style="display: inline-block; margin-top: 20px; padding: 12px 20px; background: #007bff; color: white; border-radius: 10px; font-size: 18px; font-weight: bold; text-decoration: none; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); transition: transform 0.2s ease, background 0.3s ease;">
                Start Tracking
            </a>
        </div>
        <div class="hero-image" style="flex: 1; display: flex; justify-content: center; opacity: 1; transform: translateX(0); transition: opacity 1s ease-out, transform 1s ease-out;">
            <img src="assets/images/moodhero.png" alt="Mood Tracker Preview" class="slide-in" style="width: 100%; max-width: 500px; border-radius: 12px;">
        </div>
    </section>

    <section id="mood-tracker" style="width: 100%; padding: 40px; background: #1e1e1e; border-radius: 12px;">
        
      <section id="mood-tracker" style="width: 100%; padding:40px; background: #282828; border-radius: 12px; box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.3); margin: 20px 0; position: relative; overflow: hidden; display: flex; justify-content: center;">
        <div id="mood-container" style="display: contain; width: 100%; max-width: 800px; justify-content: space-between; align-items: center; position: relative;">
      
            <!-- Mood Form -->
            <form action="save_mood.php" method="post" id="mood-form" style="flex: 1; padding: 20px; background: #343a40; border-radius: 12px; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3); transition: transform 0.5s ease-in-out; position: relative;">
                <h2 style="color: #007bff; text-align: center;">How are you feeling today?</h2>
                <br>
      
                <div id="mood-options" style="display: flex; justify-content: center; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                    <input type="radio" id="happy" name="mood" value="Happy" style="display: none;" required>
                    <label for="happy" class="mood-btn" style="background: #28a745; color: white; border: 2px solid #218838;">😃 Happy</label>
      
                    <input type="radio" id="neutral" name="mood" value="Neutral" style="display: none;" required>
                    <label for="neutral" class="mood-btn" style="background: #ffc107; color: black; border: 2px solid #d39e00;">😐 Neutral</label>
      
                    <input type="radio" id="sad" name="mood" value="Sad" style="display: none;" required>
                    <label for="sad" class="mood-btn" style="background: #dc3545; color: white; border: 2px solid #c82333;">😢 Sad</label>
      
                    <input type="radio" id="stressed" name="mood" value="Stressed" style="display: none;" required>
                    <label for="stressed" class="mood-btn" style="background: #fd7e14; color: white; border: 2px solid #e0a800;">😫 Stressed</label>
                    <input type="radio" id="anxious" name="mood" value="Anxious" style="display: none;" required>
                    <label for="anxious" class="mood-btn" style="background: #6610f2; color: white; border: 2px solid #540ed4;">😟 Anxious</label>
                </div>
            
                <label for="mood-date" style="font-weight: bold; color: #c8c8c8;">Date:</label>
                <input type="date" id="mood-date" name="mood_date" style="width: 100%; padding: 10px; border: 1px solid #007bff; border-radius: 8px; background-color: #282828; color: #c8c8c8; text-align: center; font-size: 16px; margin-bottom: 20px; cursor: pointer;">
      
                <label for="note" style="font-weight: bold; color: #c8c8c8;">Add a Note (optional):</label>
                <textarea id="note" name="note" style="width: 100%; padding: 10px; border: 1px solid #007bff; border-radius: 8px; background-color: #282828; color: #c8c8c8; font-size: 16px;"></textarea>
      
                <button type="submit" style="width: 100%; padding: 15px; background: #28a745; color: white; border: none; border-radius: 10px; font-weight: bold; font-size: 18px; margin-top: 20px; cursor: pointer; transition: 0.3s;">
                    🚀 Save Mood
                </button>
                    <!-- View Graph Button -->
          <a href="user_dashboard.php" style="width: 100%; padding: 15px; background: #007bff; color: white; border: none; border-radius: 10px; font-weight: bold; font-size: 18px; margin-top: 20px; text-align: center; display: block; text-decoration: none;">
            📊 View Graph
        </a>
            </form>
      
            <!-- Full-Screen Calendar (Hidden by Default) -->
            <div id="calendar-section" style="position: absolute; top: 0; right: -100%; width: 25%; height: 100%; background: #282828; border-left: 3px solid #007bff; box-shadow: -5px 0 15px rgba(0, 0, 0, 0.3); transition: right 0.6s ease-in-out; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <h3 style="color: #007bff;">📅 Select a Date</h3>
                <input type="date" id="calendar-input" style="width: 100%; padding: 10px; border: 2px solid #007bff; border-radius: 8px; background-color: #1e1e1e; color: #c8c8c8; text-align: center; font-size: 16px;">
                <button id="close-calendar" style="margin-top: 15px; padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 6px; cursor: pointer;">Close</button>
            </div>
        </div>
      </section>
        <!-- Year Selector Dropdown -->
        <select id="year-selector" class="year-selector" style="background-color: #282828; color: #c8c8c8; border: 2px solid #007bff;">
            <!-- Options will be populated by JavaScript -->
          </select>
          <div class="calendar-header">
            <button class="nav-button" id="prev-month">◀ Prev</button>
            <span class="month-name" id="current-month" style="color: #c8c8c8;"></span>
            <button class="nav-button" id="next-month">Next ▶</button>
        </div>
    </section>



      <!-- Calendar Grid -->
      <div id="mood-calendar" class="calendar-container" style="background-color: #282828; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);">
        <!-- Day cells will be generated here by JavaScript -->
      </div>

      <!-- Mood Color Legend -->
      <div class="legend" style="background: #282828; color: #c8c8c8; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);">
        <div class="legend-item"><span class="legend-color" style="background: #FFD700;"></span> Happy</div>
        <div class="legend-item"><span class="legend-color" style="background: #4682B4;"></span> Sad</div>
        <div class="legend-item"><span class="legend-color" style="background: #A9A9A9;"></span> Neutral</div>
        <div class="legend-item"><span class="legend-color" style="background: #FF4500;"></span> Stressed</div>
        <div class="legend-item"><span class="legend-color" style="background: #6610f2;"></span> Anxious</div>
    </div>
    
    <script>
       document.getElementById("mood-date").addEventListener("click", function(event) {
      event.preventDefault();
      document.getElementById("calendar-section").style.right = "0"; // Slide in calendar
      document.getElementById("mood-form").style.transform = "translateX(-30%)"; // Slide form to extreme left
  });

document.getElementById("close-calendar").addEventListener("click", function() {
      document.getElementById("calendar-section").style.right = "-100%"; // Hide calendar
      document.getElementById("mood-form").style.transform = "translateX(0)"; // Bring form back
  });

document.getElementById("calendar-input").addEventListener("change", function() {
          document.getElementById("mood-date").value = this.value;
      });
      document.addEventListener("DOMContentLoaded", function () {
      // Mood color mapping (case-sensitive matching the database values)
      const moodColors = {
          "Happy": "#28a745",   // Green
          "Sad": "#dc3545",     // Red
          "Neutral": "#ffc107", // Yellow
          "Stressed": "#fd7e14", // Orange
          "Anxious": "#6610f2" // Indigo
      };

      let currentYear = new Date().getFullYear();
      let currentMonth = new Date().getMonth();

      const calendarContainer = document.getElementById("mood-calendar");
      const monthName = document.getElementById("current-month");
      const yearSelector = document.getElementById("year-selector");

      // Populate Year Selector with options from 2000 to 2050
      for (let year = 2000; year <= 2050; year++) {
          const option = document.createElement("option");
          option.value = year;
          option.textContent = year;
          yearSelector.appendChild(option);
      }
      yearSelector.value = currentYear;

      // Month names array
      const monthNames = [
          "January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
      ];

      function updateCalendar() {
          // Update the header text
          monthName.textContent = `${monthNames[currentMonth]} ${currentYear}`;
          calendarContainer.innerHTML = ""; // Clear previous grid

          const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

          for (let day = 1; day <= daysInMonth; day++) {
              const dateStr = `${currentYear}-${(currentMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
              const dayCell = document.createElement("div");
              dayCell.className = "day-cell";
              dayCell.style.backgroundColor = "#343a40"; // Darker background for empty/default cells

              // Add day number at the top left
              const dayNumber = document.createElement("span");
              dayNumber.className = "day-number";
              dayNumber.textContent = day;
              dayNumber.style.color = "#c8c8c8"; // Light text color for day number
              dayCell.appendChild(dayNumber);

              // Fetch mood data for this date from PHP
              fetch(`process/get_moods_for_date.php?date=${dateStr}&user_id=<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>`)
                  .then(response => response.json())
                  .then(moods => {
                      if (moods.length > 0) {
                          // For multiple moods, create icon containers
                          const moodIconsContainer = document.createElement("div");
                          moodIconsContainer.style.cssText = "display: flex; flex-wrap: wrap; gap: 3px; justify-content: center; align-items: center; width: 100%; height: 100%; padding: 5px;";

                          // Limit to 4 moods to fit in the cell, add tooltip
                          moods.slice(0, 4).forEach(moodEntry => {
                              const moodIcon = document.createElement("span");
                              moodIcon.textContent = moodEntry.mood; // Assuming moodEntry has a 'mood' field like 😊
                              moodIcon.style.cssText = `width: 20px; height: 20px; border-radius: 50%; background-color: ${getMoodColor(moodEntry.mood)}; display: flex; align-items: center; justify-content: center; font-size: 12px;`;
                              
                              // Add tooltip
                              const tooltip = document.createElement('div');
                              tooltip.classList.add('mood-tooltip');
                              tooltip.textContent = getMoodText(moodEntry.mood);
                              moodIcon.style.position = 'relative'; // Needed for absolute positioning of tooltip
                              tooltip.style.cssText = `position: absolute; bottom: 100%; left: 50%; transform: translateX(-50%); background: #343a40; color: #c8c8c8; padding: 5px; border-radius: 5px; font-size: 12px; white-space: nowrap; opacity: 0; transition: opacity 0.2s ease-in-out; z-index: 100;`;
                              moodIcon.appendChild(tooltip);

                              moodIcon.onmouseover = (e) => { tooltip.style.opacity = 1; };
                              moodIcon.onmouseout = (e) => { tooltip.style.opacity = 0; };

                              moodIconsContainer.appendChild(moodIcon);
                          });
                           dayCell.style.backgroundColor = "transparent"; // Make cell transparent if showing icons
                          dayCell.appendChild(moodIconsContainer);
                      }
                  })
                  .catch(error => console.error("Error fetching moods for", dateStr, error));

              calendarContainer.appendChild(dayCell);
          }
      }

      // Helper to get color based on mood emoji/text
      function getMoodColor(mood) {
          switch (mood) {
              case '😊': case 'Happy': return '#28a745'; // Green
              case '😐': case 'Neutral': return '#ffc107'; // Yellow
              case '😢': case 'Sad': return '#dc3545'; // Red
              case '😠': case 'Angry': return '#fd7e14'; // Orange
              case '😟': case 'Anxious': return '#6610f2'; // Indigo
              default: return '#343a40'; // Darker background
          }
      }
      
      // Helper to get text based on mood emoji/text for tooltip
      function getMoodText(mood) {
          switch (mood) {
              case '😊': case 'Happy': return 'Happy';
              case '😐': case 'Neutral': return 'Neutral';
              case '😢': case 'Sad': return 'Sad';
              case '😠': case 'Angry': return 'Angry';
              case '😟': case 'Anxious': return 'Anxious';
              default: return 'Unknown';
          }
      }

      // Month navigation event listeners
      document.getElementById("prev-month").addEventListener("click", function () {
          currentMonth = (currentMonth - 1 + 12) % 12;
          if (currentMonth === 11) currentYear--;
          updateCalendar();
      });

      document.getElementById("next-month").addEventListener("click", function () {
          currentMonth = (currentMonth + 1) % 12;
          if (currentMonth === 0) currentYear++;
          updateCalendar();
      });

      yearSelector.addEventListener("change", function () {
          currentYear = parseInt(this.value);
          updateCalendar();
      });

      updateCalendar(); // Render calendar initially

      // Set today's date in the mood input
      const today = new Date();
      const day = String(today.getDate()).padStart(2, '0');
      const month = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
      const year = today.getFullYear();
      document.getElementById('mood-date').value = `${year}-${month}-${day}`;


  });

    </script>

  </body>
  </html>
